from django.apps import AppConfig


class TourpackageConfig(AppConfig):
    name = 'tourpackage'
